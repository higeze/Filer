#pragma once

namespace V4 {
class D2DControls;

struct Selection
{

	D2DControls* ctrls;


};


extern Selection g_selection; // see mainframe.cpp
};
