#pragma once

#include "D2DWindow.h"
#include "D2DWindowControl.h"
#include "gdi32.h"
#include "MoveTarget.h"
#include "Selection.h"