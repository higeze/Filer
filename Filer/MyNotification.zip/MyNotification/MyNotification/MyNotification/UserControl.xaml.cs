﻿namespace MyNotification
{
    /// <summary>
    /// Interaction logic for UserControlWithNotification.xaml
    /// </summary>
    public partial class UserControl
    {
        public UserControl()
        {
            InitializeComponent();
        }
    }
}
