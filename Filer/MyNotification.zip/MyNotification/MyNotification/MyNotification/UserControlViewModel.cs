﻿namespace MyNotification
{
    using System.Windows.Input;

    using Prism.Commands;
    using Prism.Interactivity.InteractionRequest;
    using Prism.Mvvm;

    public class UserControlViewModel : BindableBase
    {
        public ICommand NotificationCommand { get; private set; }


        // You need to uncomment to use the custom version of InteractionRequested.
        //public CustomInteractionRequest<INotification> NotificationRequest { get; }
        public InteractionRequest<INotification> NotificationRequest { get; }

        public UserControlViewModel()
        {
            NotificationCommand = new DelegateCommand(ExecuteNotificationCommand);

            // You need to uncomment to use the custom version of InteractionRequested.
            //NotificationRequest = new CustomInteractionRequest<INotification>();
            NotificationRequest = new InteractionRequest<INotification>();
        }

        private void ExecuteNotificationCommand()
        {
            NotificationRequest.Raise(
                new Notification
                {
                    Content = "Notification Message",
                    Title = "Notification Title"
                });
        }

    }
}
