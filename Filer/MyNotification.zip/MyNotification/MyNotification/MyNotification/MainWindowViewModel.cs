﻿namespace MyNotification
{
    using Prism.Mvvm;

    public class MainWindowViewModel : BindableBase
    {
        public UserControlViewModel UserControl { get; set; } = new UserControlViewModel();
    }
}
