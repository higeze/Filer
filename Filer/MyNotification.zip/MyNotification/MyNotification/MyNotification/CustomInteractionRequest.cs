﻿namespace MyNotification
{
    using System;

    using Prism.Interactivity.InteractionRequest;

    public class CustomInteractionRequest<T> : IInteractionRequest where T : INotification
    {
        private EventHandler<InteractionRequestedEventArgs> _onRaiseEventHandler;

        /// <summary>
        /// Fired when interaction is needed.
        /// </summary>
        public event EventHandler<InteractionRequestedEventArgs> Raised
        {
            // Ensure that only one handler can
            // be subscribed to this event.

            add
            {
                _onRaiseEventHandler = value;
            }

            remove
            {
                _onRaiseEventHandler -= value;
            }
        }

        /// <summary>
        /// Fires the Raised event.
        /// </summary>
        /// <param name="context">The context for the interaction request.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")]
        public void Raise(T context)
        {
            Raise(context, c => { });
        }

        /// <summary>
        /// Fires the Raised event.
        /// </summary>
        /// <param name="context">The context for the interaction request.</param>
        /// <param name="callback">The callback to execute when the interaction is completed.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1030:UseEventsWhereAppropriate")]
        public void Raise(T context, Action<T> callback)
        {
            _onRaiseEventHandler?.Invoke(
                this,
                new InteractionRequestedEventArgs(
                    context,
                    () =>
                    {
                        callback?.Invoke(context);
                    }));
        }
    }
}
